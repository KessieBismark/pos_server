<?php

if($action == "add_service"){
try{
    $name =mysqli_real_escape_string($conn, $_POST['name']);
    $des =mysqli_real_escape_string($conn, $_POST['des']);
    $duration =mysqli_real_escape_string($conn, $_POST['duration']);
    $cost =mysqli_real_escape_string($conn, $_POST['cost']);
    $period =mysqli_real_escape_string($conn, $_POST['period']);
    $sub =mysqli_real_escape_string($conn, $_POST['sub']);

    $cmd2 = "SELECT * FROM `services` WHERE  name='$name'";
    $query = mysqli_query($conn,$cmd2);
    $rows = mysqli_num_rows($query);
        if($rows >0){
            echo $duplicate;
        }else{         
                $cmd = "INSERT INTO `services`(`name`, `sub_category`, `description`, `duration_period`, `duration`, `duration_cost`) 
                VALUES ('$name',(select id from sub_category where name='$sub'),'$des','$period',' $duration','$cost');";
                $query3 = mysqli_query($conn,$cmd);
                if(!($query3)){
                    echo $failed;
                }else{
                    echo $true;
                }   
    }
 } catch (Exception $e) {
        mysqli_close($conn);
        echo 'Exception error: ',  $e->getMessage(), "\n";
    }
}

if($action =="update_service"){
    try{
        $id = mysqli_real_escape_string($conn, $_POST['id']);
        $name =mysqli_real_escape_string($conn, $_POST['name']);
        $des =mysqli_real_escape_string($conn, $_POST['des']);
        $duration =mysqli_real_escape_string($conn, $_POST['duration']);
        $cost =mysqli_real_escape_string($conn, $_POST['cost']);
        $period =mysqli_real_escape_string($conn, $_POST['period']);
        $sub =mysqli_real_escape_string($conn, $_POST['sub']);

        $cmd = " UPDATE `services` SET `name`='$name',`sub_category`=(select id from sub_category where name='$sub'),
        `description`='$des',`duration_period`='$period',`duration`='$duration',`duration_cost`='$cost' WHERE `id`='$id';";
        $query = mysqli_query($conn,$cmd);
        if($query){
            echo $true;
        }else{
            echo $false;
        }
     } catch (Exception $e) {
        mysqli_close($conn);
        echo 'Exception error: ',  $e->getMessage(), "\n";
    }
}

if($action =="delete_service" ){
    try{
        $id = mysqli_real_escape_string($conn, $_POST['id']);
        $cmd = "delete from `services` WHERE `id`='$id';";
        $query = mysqli_query($conn,$cmd);
        if($query){
            echo $true;
        }else{
            echo $false;
        }
     } catch (Exception $e) {
        mysqli_close($conn);
        echo 'Exception error: ',  $e->getMessage(), "\n";
    }
}

if($action == "view_service"){
    $cmd = "SELECT s.`id`, s.`name`, sc.name as sub_category,c.name as category,s.`description`,
     s.`duration_period`, s.`duration`, s.`duration_cost` FROM `services` s INNER JOIN sub_category 
     sc INNER JOIN category c on s.sub_category = sc.id and sc.cat_id =c.id";
     $query = mysqli_query($conn,$cmd);
     if(! $query ){
         echo $failed;
     }else{  
         while($view = mysqli_fetch_assoc($query)){
             $db_data[] = $view;
         }
         echo json_encode($db_data);
     }
}
?>